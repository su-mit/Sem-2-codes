package ArrayList_Sorting;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

/******************
 * This program demostarte the sorting of Array List using the collections.sort() method
 * User enters the list and then it is displays the ascending and in descending order also.   
 * 
 * @author Sumit Singh
 *
 */
public class doubleSort {
	static ArrayList<Double> doubleArray = new ArrayList<Double>();
	
	public static void main(String[] args) {
		int count = 0;
		double values = 0d;
		Scanner keyboard = new Scanner(System.in);
		
		System.out.println("Enter the number of numbers in the list");
		count = (keyboard.nextInt());
		
		System.out.println("");
		
		System.out.println("Enter the numbers: ");	
		for(int ndx = 0; ndx < count ; ndx++) {
			
			values = keyboard.nextDouble();
			
			doubleArray.add(values);
			
		}
		
		// Sorting array in ascending order.
		Collections.sort(doubleArray);
		
		System.out.println("List in ascending sort order is:");
		System.out.println(doubleArray);
		
		System.out.println("");
		
		// Sorting array in descending order.
		Collections.sort(doubleArray, Collections.reverseOrder());
			
		System.out.println("List in descending sort order is:");
		System.out.println(doubleArray);
		
	keyboard.close();
		
	}
	
}