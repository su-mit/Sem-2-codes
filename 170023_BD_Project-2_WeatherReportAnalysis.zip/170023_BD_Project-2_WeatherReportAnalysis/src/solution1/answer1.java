package solution1;

import java.io.IOException;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Set;

import org.apache.hadoop.config.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

/***
 * Description: The following code defines driver, mapper and reducer class
 * for calculating the highest temp of each year.
 * 
 * @author Sumit Singh
 *
 */
public class answer1 {

	public static class  HotAndColdMapper extends Mapper<LongWritable, Text, Text, Text> {
	
		public static final int highest_temp = 9999;
		Hashtable<String, Float> temp = new Hashtable<String, Float>();
		public void map(LongWritable longWritable, Text Value, Context context) throws IOException, InterruptedException {

			//Converting the record  to String
			String currentRecord = Value.toString();

			//Checking is the line not empty
			if (!(currentRecord.length() == 0)) {

				//date_year
				String year = currentRecord.substring(6, 10);

				//maximum temp
				float temp_Max = Float.parseFloat(currentRecord.substring(39, 45).trim());
				if (!temp.containsKey(year)) if (temp_Max != highest_temp) temp.put(year, temp_Max);
				else if (temp_Max!=highest_temp) {
					float previousTemp = temp.get(year);
					if (temp_Max>previousTemp) temp.put(year, temp_Max);
				}
				
			}

		}
@Override
protected void cleanup(
		Mapper<LongWritable, Text, Text, Text>.Context context)
		throws IOException, InterruptedException {
	Set<String> keySet = temp.keySet();
	for (String key: keySet) {
		context.write(new Text("Hottest Temperature of  " + key),
				new Text(String.valueOf(temp.get(key))));}
	}
}

	public static class HotAndColdReducer extends Reducer<Text, Text, Text, Text> {
		public void reduce(Text Key, Iterator<Text> values, Context context) throws IOException, InterruptedException {
			String temp = values.next().toString();
			context.write(Key, new Text(temp));	}
	}

	@SuppressWarnings("deprecation")
	public static void main(String[] args) throws Exception {
		Configuration config = new Configuration();
		Job job = new Job(config, "Highest Temperature of Year");
		job.setJarByClass(answer1.class);
		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(Text.class);
		job.setMapperClass(answer1.HotAndColdMapper.class);
		job.setReducerClass(answer1.HotAndColdReducer.class);
		job.setInputFormatClass(TextInputFormat.class);
		job.setOutputFormatClass(TextOutputFormat.class);
		Path outputPath = new Path(args[1]);
		FileInputFormat.addInputPath(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		outputPath.getFileSystem(config).delete(outputPath);
		System.exit(job.waitForCompletion(true) ? 0 : 1);

	}
}