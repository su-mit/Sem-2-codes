package solution4;

import java.io.IOException;
import java.util.Iterator;
import org.apache.hadoop.config.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

/***
 * Description: The following code defines MapReduce driver, mapper and reducer class 
 * for finding out maximum and minimum temperature.
 * 
 * @author Sumit Singh
 *
 */
public class answer4 {
	public static class HotAndColdMapper extends	Mapper<LongWritable, Text, Text, Text> {
		public static final int maxTemp = 9999;
		public void map(LongWritable arg0, Text Value, Context context) throws IOException, InterruptedException {
		
			//Converting the record  to String
			String currentRecord = Value.toString(); 
			if (!(currentRecord.length() == 0)) {
				
				//date
				String date = currentRecord.substring(6, 14);
				//max temp
				float temp_Max = Float.parseFloat(currentRecord.substring(39, 45).trim());
				//min temp
				float temp_Min = Float.parseFloat(currentRecord.substring(47, 53).trim());
								
				if ( temp_Max != maxTemp && temp_Min != maxTemp) {
					// Hot day
					context.write(new Text("Date: " + date+ " | "),
							new Text(String.valueOf(" Maximum Temperature: "+ temp_Max+ "\t|  Minimum Temperature: "+ temp_Min+ "\t|")));
				}
			}
		}
	}
	public static class HotAndColdReducer extends Reducer<Text, Text, Text, Text> {
		public void reduce(Text key, Iterator<Text> Values, Context context) throws IOException, InterruptedException {
			String temp = Values.next().toString();
			context.write(key, new Text(temp));
		}
	}
	@SuppressWarnings("deprecation")
	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
		Configuration config = new Configuration();
		Job job = new Job(config, "Maximum and Minimum Temperature of Each Day");
		job.setJarByClass(answer4.class);
		job.setMapOutputKeyClass(Text.class);
		job.setMapOutputValueClass(Text.class);
		job.setMapperClass(answer4.HotAndColdMapper.class);
		job.setReducerClass(answer4.HotAndColdReducer.class);
		job.setInputFormatClass(TextInputFormat.class);
		job.setOutputFormatClass(TextOutputFormat.class);
		Path outputPath = new Path(args[1]);
		FileInputFormat.addInputPath(job, new Path(args[0]));
		FileOutputFormat.setOutputPath(job, new Path(args[1]));
		outputPath.getFileSystem(config).delete(outputPath);
		System.exit(job.waitForCompletion(true) ? 0 : 1);
	}
}
